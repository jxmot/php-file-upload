# html5-file-upload-example
Source code with examples for my article on WebCodeGeeks
